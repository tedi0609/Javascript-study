import Dog from "./dog";

// Ingatlah 2 constant dog1 dan dog2 di bawah ini
const dog1 = new Dog("Leo", 4, "Chihuahua");
const dog2 = new Dog("Ben", 2, "Poodle");

// Ubah code di bawah dan export constant dog1 dan dog2
export {dog1, dog2};
