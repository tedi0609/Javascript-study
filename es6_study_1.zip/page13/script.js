const age = 24;

// Cetak hasil dari age >= 18
console.log(age>=18);

// Cetak hasil dari age < 18
console.log(age<18);

/* Ketika nilai dari age lebih besar atau sama dengan 18
dan cetak "Saya berusia lebih dari 18 tahun" */

if(age >= 18){
  console.log("Saya berusia lebih dari 18 tahun");
}