// Deklarasikan nama variable dengan nilai string "Ninja Ken"
let name = "Ninja Ken";

// Cetakan nilai nama variable
console.log(name);
