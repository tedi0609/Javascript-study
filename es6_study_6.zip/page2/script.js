const characters = ["Ninja Ken", "Baby Ben", "Guru Domba", "Birdie"];

// Cetak semua element di dalam array characters dengan menggunakan method forEach
characters.forEach((character) => 
    {console.log(character);
    });
    
