// Tambahkan parameter name ke function
const greet = (name) => {
  // Cetak pesan "Halo, ____"
  console.log(`Halo, ${name}`);  
};

// Panggil function greet dengan "Guru Domba" sebagai argument
greet("Guru Domba");
