// Definisikan constant name
const name = "Ninja Ken";

const introduce = (name) => {
  // Cetak "Saya ____" di console
  console.log(`Saya ${name}`);
};

// Panggil function introduce
introduce("Guru Domba");

// Cetak nilai dari constant name
console.log(name);
