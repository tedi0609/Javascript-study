// Deklarasikan variable number
let number = 1;

// Cetak nilai dari variable number, dan tambahkan dengan 1
console.log(number);
number += 1;
// Salin kedua baris di atas dan tempelkan di baris bawah sebanyak 4 kali
console.log(number);
number += 1;
console.log(number);
number += 1;
console.log(number);
number += 1;
console.log(number);
number += 1;
