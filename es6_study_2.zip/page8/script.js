const animals = ["anjing", "kucing", "domba"];

// Gunakan loop for untuk mencetak nilai animals di console secara berurutan
for(let i=0; i<3; i++){
  console.log(animals[i]);
}
