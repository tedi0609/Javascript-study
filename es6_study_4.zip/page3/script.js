class Animal {
}

// Tetapkan instance class Animal ke constant animal
const animal = new Animal();

// Tampilkan nilai milik constant animal
console.log(animal);
