// Definisikan class Animal
class Animal{
  
}
